# BÁO CÁO NHIỆM VỤ 12 – GIAO DIỆN THỬ NGHIỆM GRADIO

## 1. Yêu cầu

Tạo giao diện đơn giản bằng Gradio/Streamlit; kết nối pipeline đã huấn luyện; thử 3–5 tin nhắn mẫu. Có giao diện chạy được, kết quả thực nghiệm và hình minh họa.

## 2. Những việc đã hoàn thành

1. Tạo ứng dụng **Gradio** trong `app.py` để nhập tin nhắn hoặc chọn 1 trong 5 tin nhắn mẫu. Có nút **Phân loại tin nhắn**, **Chạy thử cả 5 tin nhắn**.
2. Trích xuất **đúng file mô hình V2** `NV7/naive_bayes_pipeline_v2.pkl` từ `NV7.zip` sang `models/naive_bayes_pipeline_v2.pkl`; hai file có SHA-256 trùng nhau.
3. Nạp mô hình bằng `joblib.load`, gọi `.predict()` và `.predict_proba()`; mô hình dùng `TfidfVectorizer`, `RandomOverSampler`, `MultinomialNB` và trả nhãn `ham`, `smishing`, `spam`.
4. Chạy **5 tin nhắn mới qua pipeline thật**: 5 lần đều trả về dự đoán và xác suất; 4/5 trùng với nhãn tham khảo do người thiết kế đặt. Mẫu trúng thưởng được mô hình nhận diện là `smishing`, khác nhãn tham khảo `spam` – giữ nguyên kết quả thật.
5. Kiểm thử ứng dụng Gradio qua API HTTP: trả HTTP 200; endpoint `/test_five` trả đủ 5 dòng; `/predict_one` trả nhãn dự đoán thật.
6. Kiểm thử tự động: **6 bài pytest đều đạt** trong môi trường đang chạy, có cảnh báo phiên bản scikit-learn (chi tiết mục 5).
7. Tạo ảnh minh họa kết quả từ dữ liệu kiểm thử thật, file CSV, báo cáo và hướng dẫn chạy.

## 3. Bảng 5 tin nhắn thực nghiệm

| # | Tin nhắn | Nhãn tham khảo | V2 dự đoán | Xác suất lớp dự đoán | Trùng? |
|---:|---|---|---|---:|---|
| 1 | Hi, are we still meeting at 5 pm today? | ham | **ham** | 91.67% | Có |
| 2 | I'm home now. I'll call you after dinner. | ham | **ham** | 96.05% | Có |
| 3 | Congratulations! You won a free prize. Reply WIN to claim it now. | spam | **smishing** | 91.17% | Không |
| 4 | Limited offer! Get 50% off today only. Text YES to subscribe. | spam | **spam** | 87.54% | Có |
| 5 | URGENT: Your package is held. Verify your address at https://delivery-status.example | smishing | **smishing** | 76.42% | Có |

**Lưu ý:** nhãn tham khảo được gợi ý thủ công để minh họa giao diện, không phải nhãn chuẩn xác nhận. Tỷ lệ 4/5 không đại diện cho độ chính xác tổng thể. Kết quả đánh giá 96,21% lấy từ bộ test riêng 1.160 mẫu do nhóm cung cấp.

## 4. Số liệu đánh giá V2 đã có sẵn

| Chỉ số | Giá trị |
|---|---:|
| Tập test | 1.160 |
| Dự đoán đúng | 1.116 |
| Dự đoán sai | 44 |
| Accuracy | 96,21% |
| Macro F1 | 88,86% |

Ma trận nhầm lẫn và 44 mẫu dự đoán sai có trong thư mục `data/`.

## 5. Môi trường và giới hạn

- Tệp mô hình được tạo với **scikit-learn 1.6.1**. Môi trường thử nghiệm hiện dùng scikit-learn 1.8.0 và imbalanced-learn 0.14.1; dự đoán vẫn chạy, nhưng sklearn phát cảnh báo do lệch phiên bản. File `requirements.txt` đề xuất dùng `scikit-learn==1.6.1` để đồng nhất với mô hình đã huấn luyện.
- Notebook V2 học trên cột `text_clean`. Với tin nhắn mới chưa được tiền xử lý giống tập train, chất lượng có thể khác; khi đưa vào ứng dụng thật cần thống nhất bước làm sạch.
- Chỉ nạp tệp `.pkl` từ nguồn tin cậy vì dữ liệu pickle có thể thực thi mã trong khi tải.
- Ảnh trong `anh_minh_hoa/` là **hình tổng hợp có sử dụng kết quả dự đoán thật**, không phải ảnh chụp màn hình browser. Có thể tự mở Gradio trên máy, bấm nút và chụp ảnh giao diện để nộp theo yêu cầu giảng viên.

## 6. Chạy chương trình

```powershell
cd giao_dien_phan_loai_v2
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

Mở trình duyệt tại `http://127.0.0.1:7860` và nhấn **Chạy thử cả 5 tin nhắn**.

**Trạng thái: ĐÃ HOÀN THÀNH yêu cầu chức năng được phân công.**
