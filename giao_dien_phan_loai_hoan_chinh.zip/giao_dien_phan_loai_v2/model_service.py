"""Nạp và suy luận mô hình V2 THẬT được xuất từ quá trình huấn luyện.

Không huấn luyện mô hình giả, không lấy dự đoán từ CSV để trả cho tin nhắn mới.
Chỉ nạp file joblib/pkl do nhóm tự tạo và tin cậy (pickle có thể chạy mã).
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

import joblib
import numpy as np

LABELS = ("ham", "spam", "smishing")
LABEL_VI = {"ham": "Tin nhắn bình thường (Ham)",
            "spam": "Tin nhắn rác/quảng cáo (Spam)",
            "smishing": "Tin nhắn lừa đảo (Smishing)"}
ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "models"
CANDIDATE_MODELS = (
    "naive_bayes_pipeline_v2.pkl", "model_v2.joblib", "pipeline_v2.joblib", "model_v2.pkl",
    "pipeline_v2.pkl", "model_v2_pipeline.joblib",
)


def available_models() -> list[Path]:
    """Tìm các file local, không nhận file mô hình từ người lạ qua web."""
    seen = set()
    result = []
    for parent in (MODEL_DIR, ROOT):
        for name in CANDIDATE_MODELS:
            p = parent / name
            if p.is_file() and p not in seen:
                result.append(p)
                seen.add(p)
    return result


@lru_cache(maxsize=4)
def load_model(path: str, mtime_ns: int) -> Any:
    """mtime_ns giúp nạp lại mô hình khi nhóm thay file và khởi động lại UI."""
    artifact = joblib.load(path)  # Chỉ load artifact đáng tin cậy của nhóm
    if isinstance(artifact, dict) and "pipeline" in artifact:
        return artifact
    if isinstance(artifact, dict) and (
        ("vectorizer" in artifact and "classifier" in artifact)
        or ("tfidf" in artifact and "model" in artifact)
    ):
        return artifact
    if not hasattr(artifact, "predict"):
        raise TypeError("File mô hình không chứa pipeline có .predict()")
    return artifact


def _to_label(raw: Any, artifact: Any) -> str:
    """Yêu cầu nhãn rõ ràng; không tự đoán thứ tự của nhãn số."""
    if isinstance(raw, (str, np.str_)):
        value = str(raw).strip().lower()
        if value in LABELS:
            return value
    if isinstance(artifact, dict):
        encoder = artifact.get("label_encoder")
        if encoder is not None:
            value = str(encoder.inverse_transform([raw])[0]).strip().lower()
            if value in LABELS:
                return value
        mapping = artifact.get("label_mapping")
        if mapping is not None:
            value = str(mapping.get(raw, mapping.get(str(raw), ""))).strip().lower()
            if value in LABELS:
                return value
    raise ValueError(
        f"Nhãn '{raw}' chưa được khai báo. Hãy huấn luyện với nhãn "
        "'ham', 'spam', 'smishing', hoặc lưu label_encoder/label_mapping."
    )


def predict_message(artifact: Any, message: str) -> tuple[str, dict[str, float]]:
    """Suy luận từ pipeline thật; giữ preprocessing đúng như lúc huấn luyện.

    Tốt nhất là artifact chứa TOÀN BỘ pipeline tiền xử lý + TF-IDF +
    RandomOverSampler + MultinomialNB. RandomOverSampler được áp dụng lúc fit,
    KHÔNG dùng để làm cân bằng dữ liệu lúc dự đoán.
    """
    message = str(message or "").strip()
    if not message:
        raise ValueError("Vui lòng nhập nội dung tin nhắn.")

    if isinstance(artifact, dict):
        if "pipeline" in artifact:
            model = artifact["pipeline"]
            xs = [message]
        elif "vectorizer" in artifact and "classifier" in artifact:
            vectorizer, model = artifact["vectorizer"], artifact["classifier"]
            xs = vectorizer.transform([message])
        elif "tfidf" in artifact and "model" in artifact:
            vectorizer, model = artifact["tfidf"], artifact["model"]
            xs = vectorizer.transform([message])
        else:
            raise TypeError("Thiếu pipeline hoặc vectorizer + classifier")
    else:
        model = artifact
        xs = [message]

    predicted = model.predict(xs)[0]
    label = _to_label(predicted, artifact)
    scores: dict[str, float] = {}
    if hasattr(model, "predict_proba"):
        try:
            probabilities = model.predict_proba(xs)[0]
            classes = getattr(model, "classes_", None)
            if classes is not None and len(classes) == len(probabilities):
                for cls, p in zip(classes, probabilities):
                    scores[_to_label(cls, artifact)] = float(p)
        except (AttributeError, TypeError, ValueError):
            # Không đoán thứ tự lớp từ xác suất khi artifact thiếu metadata.
            scores = {}
    return label, scores


def get_model_with_info() -> tuple[Any | None, str]:
    paths = available_models()
    if not paths:
        return None, "Chưa tìm thấy models/naive_bayes_pipeline_v2.pkl (hoặc model_v2.joblib)."
    path = paths[0]
    try:
        return load_model(str(path), path.stat().st_mtime_ns), f"Đã nạp: {path.name}"
    except Exception as exc:
        return None, f"Không thể nạp {path.name}: {exc}"
