File naive_bayes_pipeline_v2.pkl được lấy nguyên bản từ NV7.zip / NV7/naive_bayes_pipeline_v2.pkl.
Chỉ tải pipeline tin cậy; joblib/pkl có nguy cơ thực thi mã khi nạp.
Pipeline: TfidfVectorizer -> RandomOverSampler -> MultinomialNB.
