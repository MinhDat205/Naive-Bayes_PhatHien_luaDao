"""Integration test using the V2 model provided inside NV7.zip."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from model_service import get_model_with_info, predict_message
from app import EXAMPLES, test_five as run_five


def test_load_original_v2():
    model, status = get_model_with_info()
    assert model is not None, status
    assert tuple(name for name, _ in model.steps) == ("tfidf", "oversampling", "naive_bayes")
    assert set(model.classes_) == {"ham", "spam", "smishing"}


def test_inference_all_five_original_v2():
    model, status = get_model_with_info()
    assert model is not None, status
    for _, message, _ in EXAMPLES:
        label, scores = predict_message(model, message)
        assert label in ("ham", "spam", "smishing")
        assert set(scores) == {"ham", "spam", "smishing"}
        assert abs(sum(scores.values()) - 1.0) < 1e-8


def test_gradio_five_results():
    table, description = run_five()
    assert len(table) == 5
    assert len(table.columns) == 6
    assert "Đã chạy 5 tin nhắn" in description
    assert "Chưa có mô hình" not in table["Dự đoán thực tế"].tolist()
