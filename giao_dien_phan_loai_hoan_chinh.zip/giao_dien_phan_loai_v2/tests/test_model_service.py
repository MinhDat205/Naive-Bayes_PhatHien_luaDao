import sys
from pathlib import Path

import pytest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from model_service import predict_message  # noqa: E402


@pytest.fixture
def toy_pipeline():
    # Chỉ phục vụ unit test luồng suy luận; KHÔNG phải mô hình V2.
    texts = [
        "hello see you at school", "lets meet tomorrow", "hi friend call me",
        "claim your free prize now", "limited offer win prize", "discount offer now",
        "verify your bank account password", "click link to verify bank", "urgent bank login verification",
    ]
    labels = ["ham"] * 3 + ["spam"] * 3 + ["smishing"] * 3
    p = Pipeline([("tfidf", TfidfVectorizer()), ("classifier", MultinomialNB())])
    return p.fit(texts, labels)


def test_inference_with_real_pipeline_interface(toy_pipeline):
    label, scores = predict_message(toy_pipeline, "please verify your bank account")
    assert label in {"ham", "spam", "smishing"}
    assert set(scores) == {"ham", "spam", "smishing"}
    assert abs(sum(scores.values()) - 1.0) < 1e-8


def test_inference_with_vectorizer_and_classifier(toy_pipeline):
    artifact = {
        "vectorizer": toy_pipeline.named_steps["tfidf"],
        "classifier": toy_pipeline.named_steps["classifier"],
    }
    label, scores = predict_message(artifact, "Hello friend")
    assert label in {"ham", "spam", "smishing"}
    assert len(scores) == 3


def test_reject_blank(toy_pipeline):
    with pytest.raises(ValueError, match="Vui lòng"):
        predict_message(toy_pipeline, "   ")
