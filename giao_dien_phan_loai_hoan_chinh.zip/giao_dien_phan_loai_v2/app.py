"""Giao diện thử nghiệm V2: Gradio (chạy bằng `python app.py`)."""
from __future__ import annotations

import html
import json
from pathlib import Path

import gradio as gr
import pandas as pd

from model_service import LABELS, LABEL_VI, get_model_with_info, predict_message

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
with (DATA / "evaluation_v2.json").open(encoding="utf-8") as f:
    EVAL = json.load(f)
PREDICTIONS = pd.read_csv(DATA / "y_test_y_pred_v2.csv")
ERRORS = pd.read_csv(DATA / "misclassified_samples_v2.csv")

# Các tin nhắn độc lập để người thử có thể đưa qua pipeline đã huấn luyện.
# 'nhãn tham khảo' do người thiết kế gợi ý, KHÔNG phải nhãn kiểm thử của CSV.
EXAMPLES = [
    ("1. Hẹn gặp bạn bè", "Hi, are we still meeting at 5 pm today?", "ham"),
    ("2. Báo về nhà", "I'm home now. I'll call you after dinner.", "ham"),
    ("3. Trúng thưởng", "Congratulations! You won a free prize. Reply WIN to claim it now.", "spam"),
    ("4. Quảng cáo", "Limited offer! Get 50% off today only. Text YES to subscribe.", "spam"),
    ("5. Giả mạo giao hàng", "URGENT: Your package is held. Verify your address at https://delivery-status.example", "smishing"),
]
CHOICES = ["Tự nhập nội dung"] + [row[0] for row in EXAMPLES]

CSS = """
.gradio-container {max-width: 1140px !important; margin: 0 auto !important; font-family: ui-sans-serif, system-ui, sans-serif !important;}
.hero {border-radius: 20px; background: linear-gradient(122deg,#0f2852 0%,#134877 64%,#0a7f91 100%);color:#fff;padding:30px 34px;margin-bottom:18px;box-shadow: 0px 8px 24px rgba(14,54,100,.12)}
.hero h1 {font-weight:750 !important;font-size:29px !important;color:#fff !important;margin:0 0 6px !important;letter-spacing:-.5px}
.hero p {color:#dcecfb !important;font-size:15px !important;margin:0 !important;line-height:1.55}
.kicker {color:#a8dff7;font-weight:700;font-size:12px;letter-spacing:1.8px;margin-bottom:8px}
.statgrid {display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:10px 0 12px}
.stat {background:#fff;border:1px solid #e7eef8;border-radius:14px;padding:16px 18px;box-shadow:0px 2px 9px #12284b09}
.stat .k {color:#607089;font-size:13px;margin-bottom:3px}.stat .v{color:#133565;font-size:28px;font-weight:760}.stat .s{color:#758397;font-size:12px}
.sectionTitle {font-weight:700;color:#17335d;font-size:17px;margin:6px 0 8px}
.predict-card {padding:16px 18px;border-radius:13px;background:#f3f8ff;border:1px solid #d7e6f9;line-height:1.6}
.predict-card strong {font-size:19px;color:#173d72}
.predict-card.error {background:#fff8e8;border-color:#f8dc9a;color:#76540e}
.predict-card.good {background:#ebf9f5;border-color:#bde6d8}
.note {color:#61728a;font-size:13px}
.pills {display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}
.pill {background:#e7f1ff;border-radius:9px;padding:5px 9px;color:#144779;font-size:12px;font-weight:650}
@media(max-width:680px){.statgrid {grid-template-columns:repeat(2,minmax(0,1fr))}.hero{padding:22px}.hero h1{font-size:22px !important}}
"""


def metric_html() -> str:
    return f"""
    <div class="statgrid">
      <div class="stat"><div class="k">Độ chính xác V2</div><div class="v">{100*EVAL['accuracy']:.2f}%</div><div class="s">Dữ liệu kiểm thử</div></div>
      <div class="stat"><div class="k">Dự đoán đúng</div><div class="v">1.116</div><div class="s">Trong 1.160 mẫu</div></div>
      <div class="stat"><div class="k">Dự đoán sai</div><div class="v">44</div><div class="s">3,79% tập kiểm thử</div></div>
      <div class="stat"><div class="k">Macro F1-score</div><div class="v">{EVAL['macro_f1']:.3f}</div><div class="s">Đánh giá 3 lớp</div></div>
    </div>"""


def model_status_html() -> str:
    _, status = get_model_with_info()
    if status.startswith("Đã nạp"):
        return f'<div class="predict-card good">✅ <b>Đã kết nối mô hình thật:</b> {html.escape(status)}. Bạn có thể dự đoán tin nhắn mới.</div>'
    return f'<div class="predict-card error">⚠️ <b>Chưa kết nối mô hình:</b> {html.escape(status)}<div class="note">Giao diện vẫn xem được kết quả đánh giá. Muốn dự đoán trực tiếp, đặt pipeline đã huấn luyện vào thư mục <code>models/</code> rồi khởi động lại ứng dụng.</div></div>'


def set_sample(choice: str) -> str:
    return next((msg for title, msg, _ in EXAMPLES if title == choice), "")


def _render_prediction(label: str, scores: dict[str, float]) -> str:
    color = {"ham": "#1f7a55", "spam": "#a46310", "smishing": "#b43541"}[label]
    result = f'<div class="predict-card"><div class="note">KẾT QUẢ DỰ ĐOÁN TỪ PIPELINE THẬT</div><strong style="color:{color}">{html.escape(LABEL_VI[label])}</strong>'
    if scores:
        result += '<div class="pills">' + ''.join(
            f'<span class="pill">{html.escape(k)}: {100*scores[k]:.1f}%</span>'
            for k in LABELS if k in scores
        ) + '</div>'
        result += '<div class="note">Xác suất do mô hình dự đoán; không phải mức bảo đảm chính xác.</div>'
    result += '</div>'
    return result


def predict_one(message: str) -> str:
    if not str(message or "").strip():
        return '<div class="predict-card error">Vui lòng nhập nội dung tin nhắn.</div>'
    model, status = get_model_with_info()
    if model is None:
        return f'<div class="predict-card error">Chưa thể dự đoán: {html.escape(status)}. Không dùng dữ liệu CSV để giả lập dự đoán.</div>'
    try:
        predicted, scores = predict_message(model, message)
        return _render_prediction(predicted, scores)
    except Exception as exc:
        return f'<div class="predict-card error">Lỗi dự đoán: {html.escape(str(exc))}</div>'


def test_five():
    model, status = get_model_with_info()
    if model is None:
        rows = [[i, msg, LABEL_VI[expected], "Chưa có mô hình", "—", "—"]
                for i, (_, msg, expected) in enumerate(EXAMPLES, 1)]
        return pd.DataFrame(rows, columns=["STT", "Tin nhắn mẫu", "Nhãn tham khảo", "Dự đoán thực tế", "Xác suất lớn nhất", "Khớp nhãn tham khảo?"]), f"⚠️ {status} — Chưa thể thực hiện kiểm thử dự đoán trực tiếp."
    rows = []
    matched = 0
    for i, (_, msg, expected) in enumerate(EXAMPLES, 1):
        try:
            label, scores = predict_message(model, msg)
            prob = f"{100*max(scores.values()):.1f}%" if scores else "Không có"
            ok = label == expected
            matched += int(ok)
            rows.append([i, msg, LABEL_VI[expected], LABEL_VI[label], prob, "Có" if ok else "Không"])
        except Exception as exc:
            rows.append([i, msg, LABEL_VI[expected], f"Lỗi: {exc}", "—", "Không thể kiểm tra"])
    return pd.DataFrame(rows, columns=["STT", "Tin nhắn mẫu", "Nhãn tham khảo", "Dự đoán thực tế", "Xác suất lớn nhất", "Khớp nhãn tham khảo?"]), f"Đã chạy 5 tin nhắn qua pipeline thật: {matched}/5 trùng với nhãn tham khảo. Đây là các mẫu minh họa do người viết chọn, không phải tập test 1.160 mẫu; một dự đoán khác nhãn tham khảo không có nghĩa là giao diện lỗi."


def get_errors(label: str) -> pd.DataFrame:
    frame = ERRORS if label == "Tất cả" else ERRORS[ERRORS["y_test"] == label]
    return frame[["test_index", "y_test", "y_pred", "text_clean"]].rename(columns={
        "test_index": "Vị trí trong tập test", "y_test": "Nhãn thật", "y_pred": "Dự đoán V2", "text_clean": "Nội dung đã xử lý"
    }).reset_index(drop=True)


class_table = pd.DataFrame([
    {"Nhãn": name, "Số mẫu": info["support"],
     "Precision": f'{info["precision"]*100:.2f}%',
     "Recall": f'{info["recall"]*100:.2f}%',
     "F1": f'{info["f1_score"]*100:.2f}%'}
    for name, info in EVAL["per_class"].items()
])

with gr.Blocks(title="Thử nghiệm mô hình V2 | SMS Guard") as demo:
    gr.HTML('''<div class="hero"><div class="kicker">ĐỒ ÁN PHÂN LOẠI TIN NHẮN • MÔ HÌNH V2</div>
      <h1>SMS Guard · Giao diện thử nghiệm AI</h1>
      <p>Phân loại tin nhắn thành <b>Ham</b>, <b>Spam</b> và <b>Smishing</b> bằng mô hình TF-IDF + RandomOverSampler + MultinomialNB.</p></div>''')
    gr.HTML(metric_html())
    gr.HTML(model_status_html())
    with gr.Tabs():
        with gr.Tab("🔎 Dự đoán tin nhắn"):
            with gr.Row():
                with gr.Column(scale=3):
                    gr.Markdown("### Nhập nội dung cần kiểm tra")
                    choice = gr.Dropdown(choices=CHOICES, value=CHOICES[0], label="Chọn một trong 5 tin nhắn mẫu hoặc tự nhập")
                    message_box = gr.Textbox(label="Nội dung tin nhắn", lines=5,
                                             placeholder="Ví dụ: Hi, are we still meeting at 5 pm today?", max_lines=8)
                    with gr.Row():
                        run_one = gr.Button("Phân loại tin nhắn", variant="primary")
                        clear_one = gr.Button("Xóa nội dung", variant="secondary")
                with gr.Column(scale=2):
                    gr.Markdown("### Kết quả")
                    prediction_panel = gr.HTML('<div class="predict-card"><span class="note">Kết quả sẽ hiển thị tại đây sau khi nhấn Phân loại tin nhắn.</span></div>')
                    gr.Markdown("""**Giải thích nhãn:**  
• **Ham:** tin nhắn bình thường  
• **Spam:** tin nhắn quảng cáo/rác  
• **Smishing:** tin nhắn có dấu hiệu lừa đảo""")
            choice.change(fn=set_sample, inputs=choice, outputs=message_box)
            run_one.click(fn=predict_one, inputs=message_box, outputs=prediction_panel)
            clear_one.click(fn=lambda: ("", '<div class="predict-card">Đã xóa nội dung. Nhập tin nhắn để thử lại.</div>', CHOICES[0]),
                            inputs=[], outputs=[message_box, prediction_panel, choice])
            gr.Markdown("### Kiểm thử nhanh 5 tin nhắn")
            gr.Markdown("5 tin nhắn minh họa được đưa trực tiếp qua pipeline V2 thật có trong thư mục models; nhãn tham khảo do người thiết kế gợi ý (có thể khác kết quả AI).")
            test_button = gr.Button("Chạy thử cả 5 tin nhắn")
            sample_results = gr.Dataframe(headers=["STT", "Tin nhắn mẫu", "Nhãn tham khảo", "Dự đoán thực tế", "Xác suất lớn nhất", "Khớp nhãn tham khảo?"],
                                          datatype=["number", "str", "str", "str", "str", "str"], interactive=False, wrap=True,
                                          label="Bảng kết quả thử nghiệm")
            sample_note = gr.Markdown("")
            test_button.click(fn=test_five, outputs=[sample_results, sample_note])
        with gr.Tab("📊 Đánh giá mô hình V2"):
            gr.Markdown("### Kết quả tập kiểm thử đã lưu")
            gr.Markdown(f"**Tổng cộng:** {EVAL['total_test_samples']:,} tin nhắn • **Độ chính xác:** {EVAL['accuracy']*100:.2f}% • **Macro F1:** {EVAL['macro_f1']:.4f}. Các chỉ số này đọc từ `evaluation_v2.json`, không phải kết quả dự đoán trực tiếp của giao diện.")
            with gr.Row():
                with gr.Column(scale=3):
                    gr.Image(value=str(DATA / "confusion_matrix_v2.png"), label="Ma trận nhầm lẫn V2", interactive=False, buttons=["download", "fullscreen"])
                with gr.Column(scale=2):
                    gr.Markdown("#### Chỉ số từng nhóm")
                    gr.Dataframe(value=class_table, interactive=False, label="Precision / Recall / F1")
                    gr.Markdown("**Cách đọc:** hàng là nhãn thực tế, cột là nhãn dự đoán; các ô trên đường chéo thể hiện dự đoán đúng.")
            gr.Markdown("#### Phân bố nhãn thực tế và dự đoán")
            counts = pd.DataFrame({
                "Nhãn": list(LABELS),
                "Thực tế": [int((PREDICTIONS.y_test == cls).sum()) for cls in LABELS],
                "Dự đoán": [int((PREDICTIONS.y_pred == cls).sum()) for cls in LABELS],
            })
            gr.Dataframe(value=counts, interactive=False)
        with gr.Tab("🧪 Phân tích 44 trường hợp sai"):
            gr.Markdown("### Dữ liệu sai từ mô hình V2")
            gr.Markdown("Tổng **44/1.160** tin nhắn bị phân loại nhầm. Bảng dưới dùng file `misclassified_samples_v2.csv`; đây là kết quả thử nghiệm đã lưu.")
            filter_label = gr.Dropdown(["Tất cả", *LABELS], value="Tất cả", label="Lọc theo nhãn thật")
            error_table = gr.Dataframe(value=get_errors("Tất cả"), interactive=False, wrap=True, label="Các tin nhắn dự đoán sai")
            filter_label.change(fn=get_errors, inputs=filter_label, outputs=error_table)
        with gr.Tab("📘 Hướng dẫn tích hợp"):
            gr.Markdown('''### 1. Pipeline V2 đã có sẵn

Pipeline thật nằm tại `models/naive_bayes_pipeline_v2.pkl`, được lấy nguyên bản từ gói `NV7.zip`. Không cần xuất thêm mô hình để chạy giao diện.


Pipeline cần giữ **cùng cách làm sạch văn bản, TF-IDF và bộ phân loại** như lúc huấn luyện. Nếu lúc train làm sạch tin nhắn ở bên ngoài pipeline, cần tích hợp lại đúng bước này trước khi dự đoán. Nhãn đầu ra phải là `ham`, `spam`, `smishing` (hoặc lưu kèm `label_encoder` / `label_mapping`).

Nếu nhóm huấn luyện TF-IDF và MultinomialNB rời nhau, có thể lưu:

```python
joblib.dump({"vectorizer": tfidf_v2, "classifier": classifier_v2},
            "models/model_v2.joblib")
```

### 2. Chạy giao diện

```bash
pip install -r requirements.txt
python app.py
```

Mở `http://127.0.0.1:7860` và bấm **Phân loại tin nhắn** hoặc **Chạy thử cả 5 tin nhắn**. Chỉ nạp file mô hình do nhóm tự tạo, không nạp `.pkl`/`.joblib` từ nguồn không tin cậy.

### 3. Minh chứng bàn giao

- `data/evaluation_v2.json`: chỉ số V2.
- `data/confusion_matrix_v2.png`: ảnh ma trận nhầm lẫn.
- `data/y_test_y_pred_v2.csv`: 1.160 nhãn thật / dự đoán.
- `data/misclassified_samples_v2.csv`: 44 trường hợp sai.
- `anh_minh_hoa/`: hình minh họa kết quả thử 5 tin nhắn bằng pipeline thật.

**Đã kết nối:** mô hình `models/naive_bayes_pipeline_v2.pkl` được lấy từ `NV7.zip`. Nhãn của 5 tin nhắn mới là dự đoán trực tiếp. Thống kê 1.160 tin nhắn là kết quả đánh giá lưu sẵn.
''')

if __name__ == "__main__":
    demo.launch(server_name="127.0.0.1", server_port=7860, share=False, show_error=True, css=CSS, theme=gr.themes.Soft())
