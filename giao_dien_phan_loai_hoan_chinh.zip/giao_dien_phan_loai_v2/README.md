# SMS Guard – Gradio + Pipeline V2 (NV7)

Đã kết nối **pipeline V2 thực** từ `NV7.zip` vào giao diện Gradio. Không cần gửi thêm mô hình.

## Yêu cầu được giao

- Tạo giao diện thử nghiệm đơn giản bằng Gradio: **đã có** (`app.py`).
- Kết nối pipeline V2 đã huấn luyện: **đã có** (`models/naive_bayes_pipeline_v2.pkl`).
- Chạy thử 3–5 tin nhắn mẫu: **đã chạy 5** (`ket_qua_thu_5_tin_nhan.csv`).
- Ảnh minh họa thực nghiệm: `anh_minh_hoa/` (hình tạo từ kết quả suy luận thật, không phải ảnh chụp trình duyệt).

## Hướng dẫn chạy trên Windows (VS Code)

Giải nén ZIP vào thư mục riêng, mở Terminal tại thư mục đó:

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

Mở http://127.0.0.1:7860 trên trình duyệt của chính máy chạy chương trình.

Nếu Windows chặn kích hoạt venv trong PowerShell, có thể thay bằng:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```

## Thử nghiệm

1. Mở tab **Dự đoán tin nhắn**.
2. Chọn 1 trong 5 mẫu (hoặc tự nhập) và bấm **Phân loại tin nhắn**.
3. Bấm **Chạy thử cả 5 tin nhắn** để xem bảng kết quả.
4. Có thể xem ma trận nhầm lẫn và 44 trường hợp phân loại sai ở 2 tab bên cạnh.

Kết quả thật từ 5 mẫu mới: **5/5 dự đoán hoạt động**, **4/5 trùng nhãn tham khảo** (tin nhắn trúng thưởng được mô hình xếp là smishing thay vì spam). Đây là thử giao diện, không phải đánh giá accuracy: accuracy V2 **96,21%** là từ tập test 1.160 mẫu đã lưu trước đó.

## Thành phần tệp

- `app.py`: giao diện Gradio.
- `model_service.py`: nạp và gọi pipeline gốc.
- `models/naive_bayes_pipeline_v2.pkl`: mô hình V2 đã huấn luyện lấy từ NV7.zip.
- `ket_qua_thu_5_tin_nhan.csv`: tóm tắt 5 dự đoán thật.
- `ket_qua_thu_5_tin_nhan_chi_tiet.csv`: 5 dự đoán thật và xác suất của 3 lớp.
- `data/`: các số liệu đánh giá V2 được cung cấp.
- `anh_minh_hoa/`: ảnh minh họa kết quả chạy thật (dựng lại từ dữ liệu, không phải ảnh chụp giao diện live).
- `tests/`: unit test + integration test với mô hình thật.
- `BAO_CAO_NHIEM_VU_12.md`: báo cáo ngắn về các bước và kết quả.

## Kiểm tra bằng lệnh

```powershell
python -m pytest -q
```

## Lưu ý về mô hình

Mô hình gốc được lưu với **scikit-learn 1.6.1**. `requirements.txt` giữ đúng phiên bản này để tránh cảnh báo tương thích; code đã được kiểm chứng chạy suy luận với scikit-learn 1.8.0 (có warning). Notebook huấn luyện dùng cột `text_clean`, vì thế đầu vào mới nên được làm sạch tương tự tập train nếu cần đánh giá nghiêm ngặt. Chỉ mở file pickle tin cậy.
